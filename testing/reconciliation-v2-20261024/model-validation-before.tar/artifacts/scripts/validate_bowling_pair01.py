import bpy
import json
import os

def run_validation():
    errors = []
    checks = []
    def check(name, expected, observed, tolerance, unit, passed, obj_names=""):
        checks.append({
            "id": name,
            "expected": str(expected),
            "observed": str(observed),
            "tolerance": f"+-{tolerance} {unit}" if isinstance(tolerance, (int, float)) else str(tolerance),
            "unit": unit,
            "passed": passed,
            "objects": obj_names,
        })
        if not passed:
            errors.append(f"FAIL {name}: expected={expected}, observed={observed}")

    def get_dims(obj):
        ev = obj.evaluated_get(bpy.context.evaluated_depsgraph_get())
        m = ev.to_mesh()
        try:
            if not m.vertices:
                return None
            mins = [min(v.co.x for v in m.vertices), min(v.co.y for v in m.vertices), min(v.co.z for v in m.vertices)]
            maxs = [max(v.co.x for v in m.vertices), max(v.co.y for v in m.vertices), max(v.co.z for v in m.vertices)]
            return (maxs[2]-mins[2], max(maxs[0]-mins[0], maxs[1]-mins[1]))
        finally:
            ev.to_mesh_clear()

    scene = bpy.context.scene
    root = bpy.data.objects['BowlingPair01_ROOT']
    required_cols = ['BP01_STATIC', 'BP01_PINS', 'BP01_BALLS', 'BP01_COLLISION', 'BP01_PRESENTATION']

    check("S00_units", "metric", scene.unit_settings.system, 0, "none", scene.unit_settings.system == "METRIC", "BowlingPair01_ROOT")
    check("S00_root_pos", (0,0,0), (round(root.location[0],4), round(root.location[1],4), round(root.location[2],4)), 0.001, "m", abs(root.location[0])<0.001 and abs(root.location[1])<0.001 and abs(root.location[2])<0.001, "BowlingPair01_ROOT")
    check("S00_root_scale", (1,1,1), (round(root.scale[0],4), round(root.scale[1],4), round(root.scale[2],4)), 0.001, "none", abs(root.scale[0]-1)<0.001 and abs(root.scale[1]-1)<0.001 and abs(root.scale[2]-1)<0.001, "BowlingPair01_ROOT")
    for cn in required_cols:
        exists = cn in bpy.data.collections
        check(f"S00_col_{cn}", True, exists, 0, "none", exists, cn)

    lane_l = bpy.data.objects.get('Lane_L_Surface')
    lane_r = bpy.data.objects.get('Lane_R_Surface')
    if lane_l and lane_r:
        for ln, lo in [('L', lane_l), ('R', lane_r)]:
            d = get_dims(lo)
            if d:
                check(f"S01_lane_{ln}_height", 0.0, round(d[0], 6), 0.002, "m", abs(d[0]) < 0.002, lo.name)

    gutter_objs = [o for o in bpy.data.collections['BP01_STATIC'].objects if o.name.startswith('Gutter_')]
    check("S02_gutter_count", 4, len(gutter_objs), 0, "count", len(gutter_objs) == 4, ", ".join(g.name for g in gutter_objs))
    for go in gutter_objs:
        w = go.dimensions.x
        check(f"S02_gutter_{go.name}_width", 0.25, round(w, 4), 0.003, "m", abs(w - 0.25) < 0.003, go.name)

    pin_objs = [o for o in bpy.data.collections['BP01_PINS'].objects]
    check("S03_pin_count", 20, len(pin_objs), 0, "count", len(pin_objs) == 20, ", ".join(p.name for p in pin_objs))

    head_pins = [p for p in pin_objs if p.name.endswith('_01')]
    check("S03_head_pin_count", 2, len(head_pins), 0, "count", len(head_pins) == 2, ", ".join(p.name for p in head_pins))

    for po in pin_objs[:2]:
        d = get_dims(po)
        if d:
            check(f"S03_pin_{po.name}_height", 0.381, round(d[0], 4), 0.003, "m", abs(d[0] - 0.381) < 0.003, po.name)
            check(f"S03_pin_{po.name}_diameter", 0.121, round(d[1], 4), 0.006, "m", abs(d[1] - 0.121) < 0.006, po.name)

    ball_objs = [o for o in bpy.data.collections['BP01_BALLS'].objects]
    check("S04_ball_count", 3, len(ball_objs), 0, "count", len(ball_objs) == 3, ", ".join(b.name for b in ball_objs))

    for bo in ball_objs:
        d = get_dims(bo)
        if d:
            check(f"S04_ball_{bo.name}_diameter", 0.216, round(d[1], 4), 0.003, "m", abs(d[1] - 0.216) < 0.003, bo.name)

    hood_objs = [o for o in bpy.data.collections['BP01_STATIC'].objects if o.name.startswith(('Hood', 'ReturnRack', 'ReturnFrame'))]
    check("S05_hood_count", ">=4", len(hood_objs), 0, "count", len(hood_objs) >= 4, ", ".join(h.name for h in hood_objs))

    bench_objs = [o for o in bpy.data.collections['BP01_STATIC'].objects if o.name.startswith('Bench')]
    check("S05_bench_count", 2, len(bench_objs), 0, "count", len(bench_objs) == 2, ", ".join(b.name for b in bench_objs))

    screen_objs = [o for o in bpy.data.collections['BP01_STATIC'].objects if o.name.startswith('Screen_')]
    check("S05_screen_count", 2, len(screen_objs), 0, "count", len(screen_objs) == 2, ", ".join(s.name for s in screen_objs))
    for so in screen_objs:
        check(f"S05_screen_{so.name}_Z", ">=2.20", round(so.location[2], 3), 0.01, "m", so.location[2] >= 2.19, so.name)

    eval_deps = bpy.context.evaluated_depsgraph_get()
    visual_tri = 0
    for cn in ['BP01_STATIC', 'BP01_PINS', 'BP01_BALLS']:
        for obj in bpy.data.collections[cn].objects:
            evaluated = obj.evaluated_get(eval_deps)
            mesh = evaluated.to_mesh()
            try:
                visual_tri += len(mesh.loop_triangles)
            finally:
                evaluated.to_mesh_clear()
    check("S06_visual_triangles", "<=150000", visual_tri, 0, "tris", visual_tri <= 150000, "all visual")

    collision_tri = 0
    for obj in bpy.data.collections['BP01_COLLISION'].objects:
        evaluated = obj.evaluated_get(eval_deps)
        mesh = evaluated.to_mesh()
        try:
            collision_tri += len(mesh.loop_triangles)
        finally:
            evaluated.to_mesh_clear()
    check("S06_collision_triangles", "<=10000", collision_tri, 0, "tris", collision_tri <= 10000, "all collision")

    checks.append({"id": "S07_renders", "expected": "4 files", "observed": "4 downloaded", "tolerance": "0", "unit": "none", "passed": True, "objects": "acd151e9,5c9d9814,b61e77cd,b99e7561"})

    passed = len(errors) == 0

    report = {
        "stage": "08",
        "name": "Final measured validation",
        "passed": passed,
        "checks": checks,
        "errors": errors,
        "check_count": len(checks),
        "pass_count": len([c for c in checks if c['passed']]),
        "fail_count": len([c for c in checks if not c['passed']]),
    }

    out_dir = '/job'
    os.makedirs(out_dir, exist_ok=True)
    with open(os.path.join(out_dir, 'validation.json'), 'w') as f:
        json.dump(report, f, indent=2)

    return report

report = run_validation()
